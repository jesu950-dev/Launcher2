package com.jesu.launcher

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.WebView
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : Activity(), LocationListener {
    private lateinit var web: WebView

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        web = WebView(this)
        web.setBackgroundColor(Color.BLACK)
        setContentView(web)
        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = true
            @Suppress("DEPRECATION")
            allowUniversalAccessFromFileURLs = true
        }
        web.addJavascriptInterface(Bridge(), "Android")
        web.loadUrl("file:///android_asset/index.html")
    }

    override fun onResume() { super.onResume(); hideBars(); startLoc() }
    override fun onPause() {
        super.onPause()
        (getSystemService(LOCATION_SERVICE) as LocationManager).removeUpdates(this)
    }
    @Deprecated("launcher: no sale con atrás")
    override fun onBackPressed() {}

    private fun hideBars() {
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN or
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
            View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
    }

    // ---- GPS (velocidad real) ----
    private fun startLoc() {
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION), 1); return
        }
        val lm = getSystemService(LOCATION_SERVICE) as LocationManager
        try {
            lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000L, 0f, this)
            lm.getLastKnownLocation(LocationManager.GPS_PROVIDER)?.let { onLocationChanged(it) }
        } catch (e: Exception) {}
    }
    override fun onRequestPermissionsResult(c: Int, p: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(c, p, r); startLoc()
    }
    override fun onLocationChanged(l: Location) {
        val js = "window.onLoc&&onLoc(${l.latitude},${l.longitude},${l.speed * 3.6})"
        web.post { web.evaluateJavascript(js, null) }
    }
    @Deprecated("old API") override fun onStatusChanged(p: String?, s: Int, e: Bundle?) {}
    override fun onProviderEnabled(p: String) {}
    override fun onProviderDisabled(p: String) {}

    // ---- Música que suena (YouTube Music, Spotify, etc.) ----
    private fun controller(): MediaController? = try {
        (getSystemService(MEDIA_SESSION_SERVICE) as MediaSessionManager)
            .getActiveSessions(ComponentName(this, MediaListener::class.java)).firstOrNull()
    } catch (e: SecurityException) { null }

    inner class Bridge {
        @JavascriptInterface fun media(): String {
            val c = controller() ?: return "{}"
            val m = c.metadata; val s = c.playbackState
            return JSONObject()
                .put("t", m?.getString(MediaMetadata.METADATA_KEY_TITLE) ?: "")
                .put("a", m?.getString(MediaMetadata.METADATA_KEY_ARTIST) ?: "")
                .put("d", m?.getLong(MediaMetadata.METADATA_KEY_DURATION) ?: 0L)
                .put("x", s?.position ?: 0L)
                .put("p", s?.state == PlaybackState.STATE_PLAYING).toString()
        }
        @JavascriptInterface fun cmd(x: String) {
            val t = controller()?.transportControls ?: return
            when (x) { "play" -> t.play(); "pause" -> t.pause(); "next" -> t.skipToNext(); "prev" -> t.skipToPrevious() }
        }
        @JavascriptInterface fun notifAccess() = go(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS"))
        @JavascriptInterface fun sound() = go(Intent(Settings.ACTION_SOUND_SETTINGS))
        @JavascriptInterface fun dial() = go(Intent(Intent.ACTION_DIAL))
        @JavascriptInterface fun open(p: String): Boolean {
            val i = packageManager.getLaunchIntentForPackage(p) ?: return false
            go(i); return true
        }
        @JavascriptInterface fun apps(): String {
            val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val out = JSONArray()
            packageManager.queryIntentActivities(q, 0)
                .filter { it.activityInfo.packageName != packageName }
                .sortedBy { it.loadLabel(packageManager).toString().lowercase() }
                .forEach { out.put(JSONObject().put("l", it.loadLabel(packageManager).toString()).put("p", it.activityInfo.packageName)) }
            return out.toString()
        }
        private fun go(i: Intent) { i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); startActivity(i) }
    }
}
