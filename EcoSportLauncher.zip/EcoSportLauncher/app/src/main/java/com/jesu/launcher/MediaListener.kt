package com.jesu.launcher

import android.service.notification.NotificationListenerService

// Vacío a propósito: al activar el "acceso a notificaciones" para esta app,
// Android permite leer qué música suena y controlarla (pausa, siguiente, anterior).
class MediaListener : NotificationListenerService()
